package CommonPage;
import CommonPage.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BasePage {
    public WebDriver driver;
    public CommonMethods commonMethods;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        commonMethods = new CommonMethods(driver);
    }
}
