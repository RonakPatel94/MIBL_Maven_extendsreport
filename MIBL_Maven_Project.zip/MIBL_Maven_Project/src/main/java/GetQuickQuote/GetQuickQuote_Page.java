package GetQuickQuote;
import CommonPage.BasePage;
import CommonPage.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class GetQuickQuote_Page extends BasePage {
    public GetQuickQuote_Page(WebDriver driver) {
        super(driver);

       //private prop = new Properties();
    }

    //private java.util.Properties prop = null;
    FileInputStream input = null;
    public void readPropertiesFile() throws IOException {

        Properties  prop = new Properties();
        try {
            InputStream input = new FileInputStream("D:\\Automation\\MIBL_Maven_Project\\src\\main\\resources\\TestData.properties");

            prop.load(input);

            System.out.println(input);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
   /* public String getPropertyValue(String key) {
        return prop.getProperty(key);
    }*/
    CommonMethods commonMethods = new CommonMethods(driver);
    ////////////////////////Locator Start//////////////////////////////
    public By aboutus = By.xpath("//a[contains(text(),'About Us')]");
    public By btnQuickQuote = By.xpath("//span[contains(text(),'Get a Quick Quote')]");
    public By btnparish = By.xpath("//span[contains(text(),'Clarendon')]");
    public By btnClarendon = By.xpath("//span[contains(text(),'Aenon Town')]");
    public By btnselectvehicle = By.xpath("//div[@id='vehicleTypeDivId']//div[2]//label[1]");
    public By btncontinue = By.id("btnContinue");
    public By btnmanufactureyear = By.id("selectValue");
    public By inputmanufacturedyear = By.xpath("//label[contains(text(),'2020')]");
    public By btnvehiclemaker = By.id("selectYear");
    public By inputvehiclemaker = By.xpath("//div[@id='vehicleMakeTypesDivId']//div[4]//div[1]//label[1]");
    public By btnvehiclemodel = By.xpath("//div[@id='vehicleModelDivId']//button[@id='selectValue']//*");
    public By inputvehiclemodel = By.xpath("//label[contains(text(),'Pulsar')]");
    public By btnprimaryuse = By.xpath("//span[contains(text(),'Social and Domestic (including travelling to and f')]");
    public By btndistancetravel = By.xpath("//div[@class='form-group vehicle-type-radio yellow-gray-radio dist-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    public By btncurrentstatumotorcyclepayment = By.id("paymentStatus0");
    public By btntypeofcover = By.xpath("//span[contains(text(),'Insured only')]");
    public By btnComprehensive = By.xpath("//span[contains(text(),'Comprehensive')]");
    public By btnmotorcycleownedcompny = By.xpath("//label[@id='vehicleCompanyOwned0']");
    public By inputcompanyname = By.id("companyofName");
    public By btnvehiclePurchased = By.xpath("//label[@id='vehiclePurchased0']");
    public By btnvehicalnewuser = By.id("vehicleNewUsed0");
    public By btnvehicleImported = By.id("vehicleImported0");
    public By btnvehicleimportedvalue = By.xpath("//div[@class='form-group vehicle-type-radio yellow-gray-radio vehicle-import-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    public By btnIsImportedWithSalvageCertificate = By.id("IsImportedWithSalvageCertificate0");
    public By btncolorID = By.xpath("//div[@id='colourDivId']//div[2]//label[1]");
    public By btnValuationProformainvoice = By.id("ValuationProformainvoice0");
    public By btnvehicleValue = By.id("vehicleValue");
    public By btnVehicleModified = By.id("IsVehicleModified0");
    public By btnsecuredOvernightDiv = By.xpath("//div[@id='securedOvernightDivId']//div[3]//label[1]");
    public By btnvehicleSometimesUsedAsTrailer = By.xpath("//div[@id='vehicleSometimesUsedAsTrailerDivId']//div[@class='group-step form-group vehicle-type-radio yellow-gray-radio cover-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    public By btnRoadworthyAndGoodCondition = By.id("RoadworthyAndGoodCondition0");
    public By btnisMileageInKm = By.id("isMileageInKmDivId");
    public By btnmileageDivId = By.xpath("//input[@placeholder='insert numbers mileage/kilometers']");
    public By btnenginecctype = By.id("ccHpTypeDivId");
    public By dropEnginecc = By.xpath("//label[contains(text(),'125')]");
    public By btnNextForm = By.id("btnNextForm");
    public By btnsoleOwner = By.id("soleOwner0");
    public By inputfirstname = By.xpath("//input[@placeholder='First Name']");
    public By inputmiddlename = By.xpath("//input[@placeholder='Middle Name']");
    public By inputlastname = By.xpath("//input[@placeholder='Last Name']");
    public By btntitle = By.xpath("//div[@class='group-step form-group vehicle-type-radio yellow-gray-radio cover-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    public By Gender = By.id("inGender0");
    public By Dateofbirth = By.id("clientDob");
    public By maritalstatus = By.xpath("//div[@class='group-step section py-4 py-xl-5 fade show ng-scope']//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    public By maritalstatus1 = By.xpath("//div[@class='group-step section py-4 py-xl-5 fade show ng-scope']//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[1]//label[1]//span[1]");
    //By maritalstatus = By.xpath("//div[@class='group-step section py-4 py-xl-5 fade show ng-scope']//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[2]//label[1]");
    public By btnvalidprovisional = By.xpath("//span[contains(text(),'Active')]");
    public By drpissueDateOfProvisionalLicense = By.xpath("//input[@name='issueDateOfProvisionalLicense']");
    public By country = By.xpath("//span[contains(text(),'CANADA')]");
    public By presentlyemployed = By.xpath("//span[contains(text(),'Yes')]");
    public By workindustry = By.xpath("//span[contains(text(),'Computer & Software')]");
    public By mainoccupation = By.id("mainOccupationDivId");
    public By btncredit = By.xpath("//span[@class='mib mib-Excellent']");
    public By btneducation = By.xpath("//div[@id='educationDivId']//div[4]//label[1]");
    public By btnmotorinsurancepolicy = By.id("isHaveMotorInsurancePolicyName0");
    public By btninsurancecompany = By.xpath("//div[@class='row no-gutters border-left-dashed border-top-dashed']//div[1]//div[1]//label[1]");
    public By btnvehicles = By.id("haveMoreThanTwoVehicles0");
    public By inputemailaddress = By.xpath("//input[@placeholder='Insert email address']");
    public By btntravelwithbaby = By.id("babyOnBoard0");
    public By btnages = By.xpath("//div[@id='babyAgeDivId']//div[2]//label[1]");
    public By btnmedically = By.xpath("//button[@id='selectValue']");
    public By btnmedically1 = By.xpath("//span[contains(text(),'No to all')]");
    public By btnaccidentclaim = By.id("accidentsorClaimsInsured1");
    public By btndrivinghistory = By.id("receivedTicketInsured1");
    public By btnprosecuted = By.id("motorOffenseInsured1");
    public By btnapplicationdeclined = By.id("declinedInsured1");
    public By btnexcessincreased = By.id("specialConditionInsured1");
    public By btncancelledorrenewal = By.id("policyCancelledInsured1");
    public By btnconsecutiveperiod = By.id("notDrivenInsured1");
    public By btninfo = By.xpath("//span[contains(text(),'Yes! The information is correct')]");
    public By btnspecialdiscount = By.xpath("//div[@id='SpecialDiscountDivId']//div[2]//label[1]");
    public By btnNonCommissioned = By.id("noncommision0");
    public By btncamerainstalled = By.id("camerainstalledonvehiclemain0");
    public By btnfulltimegovernmentemployee = By.id("areYouGovernmentEmployee0");
    public By btnhomeownerpolicy = By.id("homeOwnerPolicy0");
    public By btninsurerwithpolicy = By.xpath("//div[@class='row no-gutters border-left-dashed border-top-dashed']//div[1]//div[1]//label[1]");
    public By btnyearshomeownerpolicy = By.xpath("//div[@id='noOfYearsWithHomePolicyDivId']//div[2]//label[1]");
    public By btnbuyhomeownerpolicy = By.id("broker1");
    public By btnIsthisvehiclecurrentlyinsured = By.id("existingCover1");
    public By btnpolicytostart = By.xpath("//div[@id='policyStartDivId']//div[2]//label[1]");
    public By btnPolicyStartDate = By.id("PolicyStartDate");
    public By btnNCD = By.xpath("//div[@id='noClaimDiscountDivId']//div[2]//label[1]");
    public By btnNCDtovehicle = By.id("isApplyThisNCD1");
    public By btnanothermotorinsurancepolicy = By.id("motorPolicy1");
    public By btnanyartisticpaint = By.id("artisticPaintFinishes1");
    public By txtcarrier = By.xpath("//div[@id='quoteListDivId']//div[2]//div[2]//span[2]");
    public By btnshowquote = By.xpath("//span[contains(text(),'Please show me the lowest Quotes with their Covera')]");
    public By tblbtnbuy = By.xpath("//table[@class='table table-bordered mb-0']");
    public By lowestbuyvalue = By.xpath("//th[2]//a[1]");
    public By inputTRN = By.xpath("//div[@id='taxpayerRegistrationNumberDivId']//input[@placeholder='xxx-xxx-xxxx']");
    public By btncloseassociateholding = By.xpath("//label[@id='isRelativeProminentPublicPositionInsured1']");
    public By btnmothermaidenname = By.xpath("//input[@placeholder='Insert name']");
    public By inputaddress = By.xpath("//input[@id='autocompleteClient']");
    public By inputstreetname = By.xpath("//input[@id='streetname']");
    public By inputstreetnumber = By.xpath("//input[@id='streetnumber']");
    public By btnIsyourmailingaddress = By.xpath("//label[@id='isMailingAddressSameInsured0']");
    public By inputcompanyname1 = By.xpath("//input[@placeholder='Insert name of company']");
    public By inputmobile = By.xpath("//div[@id='residenceMobileNoDivId']//input[@placeholder='xxx-xxx-xxxx']");
    public By inputwork = By.xpath("//div[@id='businessPhoneNoDivId']//input[@placeholder='xxx-xxx-xxxx']");
    public By inputResidential = By.xpath("//div[@id='residencePhoneNoDivId']//input[@placeholder='xxx-xxx-xxxx']");
    public By inputmotorcycleenginenumber = By.xpath("//input[@placeholder='Insert engine number']");
    public By inputmotorcycleChassisnumber = By.xpath("//input[@placeholder='Insert chassis number']");
    public By btnsalary = By.xpath("//span[contains(text(),'Salary')]");
    public By btnfullpayment = By.xpath("//span[contains(text(),'Full Payment')]");
    public By btncreditcard = By.xpath(" //label[@id='crediDebitRadio0']");
    public By btnmastercard = By.xpath("//span[contains(text(),'MASTER CARD')]");
    public By inputcardname = By.xpath(" //input[@placeholder='Name on credit/debit card']");
    public By inputcardnumber = By.xpath("//input[@placeholder='Card number']");
    public By btndropclickmonth = By.id("selectValue");
    public By drpcardmonth = By.xpath("//label[contains(text(),'Mar')]");
    public By btndropclick = By.xpath("//span[contains(text(),'Select year')]");
    public By drpcardyear = By.xpath("//label[contains(text(),'2023')]");
    public By inputsecuritycode = By.xpath("//input[@placeholder='Card security code']");
    /////////////////////////////Locator End///////////////////////////
}