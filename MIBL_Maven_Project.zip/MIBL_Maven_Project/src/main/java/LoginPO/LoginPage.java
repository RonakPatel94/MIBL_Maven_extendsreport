package LoginPO;

public class LoginPage {
}
