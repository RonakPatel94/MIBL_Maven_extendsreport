package GetQuickQuoteTest;

import CommonPage.BasePage;
import CommonPage.CommonMethods;
import CommonPage.ReportTest;
import GetQuickQuote.GetQuickQuote_Page;
import com.aventstack.extentreports.Status;
import com.sun.istack.internal.NotNull;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class GetQuickQuote_Test extends ReportTest {
    //public String email = "";
    private int flag = 1;

    //private java.util.Properties prop = null;
    public GetQuickQuote_Test() {
    }

    public GetQuickQuote_Test(WebDriver passDriver, int Flag) {
        driver = passDriver;
        flag = Flag;
    }


    @Test
    public void QuickQuote() {
        if (flag > 0) {
            test = extent.createTest("MIBL Automation Testing");
            test.assignCategory("Get QuickQuote Module");
        }
        test.log(Status.INFO, "Testing Started");

        GetQuickQuote_Page getquickQuote_page = new GetQuickQuote_Page(driver);
        CommonMethods commonMethods = new CommonMethods(driver);
        Properties prop = new Properties();

        test.log(Status.INFO, "Get QuickQuote Test Case");

        //Step 1: Click on GetQuickQuote Button
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnQuickQuote), "Unable to Click on GetQuickQuote");
        test.log(Status.PASS, "Click on GetQuickQuote");

        //Step 2: Click on Which parish do you live in?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnparish), "Unable to Click on parish");
        test.log(Status.PASS, "Click on Parish");

        //Step 3: Where in Clarendon do you Live?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnClarendon), "Unable to Click on Clarendon");
        test.log(Status.PASS, "Click on Clarendon");

        //Step 4: Which vehicle do you wish to insure?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnselectvehicle), "Unable to Click on vehicle");
        test.log(Status.PASS, "Click on vehicle");

        //Step 5: Click on Continue Button?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btncontinue), "Unable to Click Continue Button");
        test.log(Status.PASS, "Click on Continue Button");

        //Step 6: Select year of manufacture
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnmanufactureyear), "Unable to year of manufacture");
        test.log(Status.PASS, "Select year of manufacture from dropdown");

        //Step 7: Select year of manufacture From Dropdown
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.inputmanufacturedyear), "Unable to year of manufacture");
        test.log(Status.PASS, "Click on year of manufacture");

        //Step 8: What is the make of your motorcycle from given list?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehiclemaker), "Unable to select make of your motorcycle");
        test.log(Status.PASS, "Select on maker of your motorcycle from dropdown");

        //Step 9: What is the make of your motorcycle from given list?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.inputvehiclemaker), "Unable to select make of your motorcycle");
        test.log(Status.PASS, "Select on maker of your motorcycle");

        //Step 10: Please select the model of your motorcycle
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehiclemodel), "Unable to select model of motorcycle");
        test.log(Status.PASS, "Click on model of motorcycle from dropdown");

        //Step 11: Please select the model of your motorcycle
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.inputvehiclemodel), "Unable to select model of motorcycle");
        test.log(Status.PASS, "Click on model of motorcycle");

        //Step 12: Please primarily use my motorcycle to
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnprimaryuse), "Unable to select primarily use my motorcycle to");
        test.log(Status.PASS, "Click on primarily use my motorcycle to");

        //Step 13: What distance do you travel each way?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btndistancetravel), "Unable to select distance do you travel each way");
        test.log(Status.PASS, "Click on distance do you travel each way");

        //Step 14: What is the current status on your motorcycle payment?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btncurrentstatumotorcyclepayment), "Unable to select current status on your motorcycle payment");
        test.log(Status.PASS, "Click on current status on your motorcycle payment");

        //Step 15: I am interested in this type of cover
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btntypeofcover), "Unable to select interested in this type of cover");
        test.log(Status.PASS, "Click on interested in this type of cover");

        //Step 16: I am interested in Comprehensive
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnComprehensive), "Unable to select I am interested in Comprehensive");
        test.log(Status.PASS, "Click on Comprehensive");

        //Step 17: Is this motorcycle owned by a company?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnmotorcycleownedcompny), "Unable to select motorcycle owned by a company");
        test.log(Status.PASS, "Click on motorcycle owned by a company");

/*        //Step 18: Is this motorcycle owned by a company?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnmotorcycleownedcompny), "Unable to select motorcycle owned by a company");
        test.log(Status.PASS, "Click on motorcycle owned by a company");*/

        //Step 18: Comapany name?
        String companyname = "Abc";
        //Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnmotorcycleownedcompny));
        Assert.assertTrue(commonMethods.enterTextInInputField(getquickQuote_page.inputcompanyname, companyname), "Unable to insert vehicle value");
        test.log(Status.PASS, "insert vehicle value");

        //Step 19: Have you just purchased this motorcycle?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehiclePurchased), "Unable to purchased this motorcycle");
        test.log(Status.PASS, "Click on purchased this motorcycle");

        //Step 20: click on  motorcycle new or used?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehicalnewuser), "Unable to select the motorcycle new or used?");
        test.log(Status.PASS, "Click on the motorcycle new or used?");

        //Step 21: Did you import this motorcycle?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehicleImported), "Unable to select import this motorcycle?");
        test.log(Status.PASS, "Click on import this motorcycle?");

        //Step 22: Was this motorcycle imported on a salvage certificate?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehicleimportedvalue), "Unable to select imported on a salvage certificate value");
        test.log(Status.PASS, "Click on imported on a salvage certificate value");

        //Step 23: Was this motorcycle imported on a salvage certificate?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnIsImportedWithSalvageCertificate), "Unable to select imported on a salvage certificate");
        test.log(Status.PASS, "Click on imported on a salvage certificate");

        //Step 24: vehical color
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btncolorID), "Unable to select color");
        test.log(Status.PASS, "Click on color");

        //Step 25: Do you have a valuation/ pro-forma invoice for this motorcycle?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnValuationProformainvoice), "Unable to valuation/ pro-forma invoice for this motorcycle");
        test.log(Status.PASS, "Click on valuation/ pro-forma invoice for this motorcycle");

        //Step 26: Do you have a valuation/ pro-forma invoice for this motorcycle?
        String Vehiclevalue = "100000";
        Assert.assertTrue(commonMethods.enterTextInInputField(getquickQuote_page.btnvehicleValue, Vehiclevalue), "Unable to insert vehicle value");
        test.log(Status.PASS, "insert vehicle value");

        //Step 27: Does this motorcycle have any high performance modification?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnVehicleModified), "Unable to click on vehicle modification");
        test.log(Status.PASS, "Click on vehicle modification");

        //Step 28: How will this motorcycle be secured overnight?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnsecuredOvernightDiv), "Unable to click motorcycle be secured overnight?");
        test.log(Status.PASS, "click motorcycle be secured overnight");

        //Step 29: How will this motorcycle be secured overnight?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnvehicleSometimesUsedAsTrailer), "Unable to click motorcycle be used as a trailer sometimes");
        test.log(Status.PASS, "click motorcycle be used as a trailer sometimes");

        //Step 30: Will this motorcycle be used as a trailer sometimes?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnRoadworthyAndGoodCondition), "Unable to click Is this motorcycle roadworthy and in good condition?");
        test.log(Status.PASS, "click motorcycle roadworthy and in good condition");

        //Step 31: Insert the current Mileage/Kilometers of your motorcycle
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnisMileageInKm), "Unable to click current Mileage/Kilometers of your motorcycle");
        test.log(Status.PASS, "click on Mileage/Kilometers of your motorcycle");

        //Step 32: Insert your vehicle’s current engine capacity or CC rating
        String mileage = "50";
        Assert.assertTrue(commonMethods.enterTextInInputField(getquickQuote_page.btnmileageDivId, mileage), "Unable to insert current Mileage/Kilometers of your motorcycle");
        test.log(Status.PASS, "Insert Mileage/Kilometers of your motorcycle");

        //Step 33: Insert your vehicle’s current engine capacity or CC rating
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnenginecctype), "Unable to click engine CC");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.dropEnginecc), "Unable to click Engine CC Dropdown");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnNextForm), "Unable to click next button");
        test.log(Status.PASS, "click on vehicle’s current engine capacity or CC rating");

        //Step 34: Are you the sole owner of the vehicle?
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(getquickQuote_page.btnsoleOwner), "Unable to click sole owner of the vehicle?");
        test.log(Status.PASS, "click on sole owner of the vehicle");






    }
}
